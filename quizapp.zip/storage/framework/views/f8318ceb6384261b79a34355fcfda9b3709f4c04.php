<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
        
        <div class="container-fluid" style="background-color: #FFFFFF;box-shadow: 0 2px rgba(0, 0, 0, 0.1);">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('home-leaderboard')->html();
} elseif ($_instance->childHasBeenRendered('IBKqiWD')) {
    $componentId = $_instance->getRenderedChildComponentId('IBKqiWD');
    $componentTag = $_instance->getRenderedChildComponentTagName('IBKqiWD');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('IBKqiWD');
} else {
    $response = \Livewire\Livewire::mount('home-leaderboard');
    $html = $response->html();
    $_instance->logRenderedChild('IBKqiWD', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            
            
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('home-slider')->html();
} elseif ($_instance->childHasBeenRendered('tsB0Rst')) {
    $componentId = $_instance->getRenderedChildComponentId('tsB0Rst');
    $componentTag = $_instance->getRenderedChildComponentTagName('tsB0Rst');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('tsB0Rst');
} else {
    $response = \Livewire\Livewire::mount('home-slider');
    $html = $response->html();
    $_instance->logRenderedChild('tsB0Rst', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\Maruf Nishan\Desktop\quizapp\resources\views/welcome.blade.php ENDPATH**/ ?>