<a href="/">
    <img src="<?php echo e(asset('/images/logo.jpeg')); ?>" alt="Quiz Site" style="height: 50px;width:80px;" />
</a><?php /**PATH C:\Users\Maruf Nishan\Desktop\quizapp\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>