<div>
     <?php $__env->slot('header', null, []); ?> 
        <div class="md:flex justify-between">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('সকল চাকরির প্রস্তুতি')); ?>

            </h2>
        </div>
     <?php $__env->endSlot(); ?>
    
    <div class="container my-3" style="background-color: #FFFFFF;">
        <div class="row">
            <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 d-flex justify-content-around my-3">     
            <a href="<?php echo e(route('jobPeparation',['id'=>$teacher->id,'cat_id' => $teacher->cat_id])); ?>">
                <div class="card" style="width: 18rem;">
                    <img src="<?php echo e(asset('assets/img/profile/teacher1.png')); ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title"><b>Name : <?php echo e($teacher->name); ?></b></h5>
                        <p class="text-sm"><b>Subject :</b> <?php echo e($teacher->subject); ?></p>
                    </div>
                </div>
            </a>
                </div>   
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    
</div>
<?php /**PATH C:\Users\Maruf Nishan\Desktop\quizapp\resources\views/livewire/all-teacher-component.blade.php ENDPATH**/ ?>