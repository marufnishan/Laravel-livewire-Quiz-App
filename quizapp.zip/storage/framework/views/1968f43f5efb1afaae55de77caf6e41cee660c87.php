
<nav class="navbar navbar-expand-lg" style="background-color: #FFFFFF;box-shadow: 0 2px rgba(0, 0, 0, 0.1);">
    <div class="container">
        <a href="/">
            <img src="<?php echo e(asset('assets/img/logo/logo.jpg')); ?>" alt="" style="height: 50px;width:80px;">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText"
            aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarText">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0" style="line-height: 2rem;
                font-weight: 500;
                font-size: 0.875rem;">
                <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                <a class="nav-link" href="<?php echo e(route('adminhome')); ?>" :active="request()->routeIs('adminhome')">এডমিন
                    ড্যাশবোর্ড</a>
                <?php endif; ?>
                
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('champPractice')); ?>"
                        :active="request()->routeIs('champPractice')">চ্যাম্পিয়নশিপ প্রস্তুতি</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('Championship')); ?>"
                        :active="request()->routeIs('Championship')">চ্যাম্পিয়নশিপ</a>
                </li>
                <li class="nav-item">
                    <div class="dropdown"><a class="nav-link">চাকরির প্রস্তুতি
                        </a>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('catecogy-component')->html();
} elseif ($_instance->childHasBeenRendered('l3773298747-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3773298747-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3773298747-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3773298747-0');
} else {
    $response = \Livewire\Livewire::mount('catecogy-component');
    $html = $response->html();
    $_instance->logRenderedChild('l3773298747-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>
                </li>
                <li class="nav-item">

                    <div class="dropdown"><a class="nav-link">লিডারবোর্ড
                        </a>
                        <div class="dropdown-content">
                            <a href="<?php echo e(route('QuizledarBoard')); ?>">কুইজ</a>
                            <?php if(auth()->check() && auth()->user()->hasRole('user|admin|superadmin')): ?>
                            <a href="<?php echo e(route('JobledarBoard')); ?>">চাকরির প্রস্তুতি</a>
                            <a href="<?php echo e(route('ChampledarBoard')); ?>">চ্যাম্পিয়নশিপ</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </li>
            </ul>
            <span class="navbar-text">
                <?php if(Route::has('login')): ?>
                <?php if(auth()->guard()->check()): ?>
                <div class="dropdown"><a class="nav-link">
                        <?php if(Laravel\Jetstream\Jetstream::managesProfilePhotos()): ?>
                        <button
                            class="flex text-sm me-3 border-2 border-transparent rounded-full focus:outline-none focus:border-gray-300 transition">
                            <img class="h-12 w-12 rounded-full object-cover" src="<?php echo e(Auth::user()->profile_photo_url); ?>"
                                alt="<?php echo e(Auth::user()->name); ?>" />
                        </button>
                        <?php else: ?>
                        <span class="inline-flex rounded-md">
                            <button type="button"
                                class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-500 bg-white hover:text-gray-700 focus:outline-none transition">
                                <?php echo e(Auth::user()->name); ?>


                                <svg class="ml-2 -mr-0.5 h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"
                                    fill="currentColor">
                                    <path fill-rule="evenodd"
                                        d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                                        clip-rule="evenodd" />
                                </svg>
                            </button>
                        </span>
                        <?php endif; ?>
                    </a>
                    <div class="dropdown-content">
                        <a href="<?php echo e(route('profile.show')); ?>">Profile</a>
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                    this.closest('form').submit();">Log Out</a>
                        </form>
                    </div>
                    <?php else: ?>
                    <div class="dropdown"><a class="nav-link">
                            <span class="inline-flex rounded-md">
                                <button type="button"
                                    class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-500 bg-white hover:text-gray-700 focus:outline-none transition">
                                    Authentication
                                </button>
                            </span>
                        </a>
                        <div class="dropdown-content">
                            <a href="<?php echo e(route('login')); ?>"
                                class="text-sm text-gray-700 dark:text-gray-500 underline">Log in</a>
                            <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>"
                                class="text-sm text-gray-700 dark:text-gray-500 underline">Register</a>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                        <?php endif; ?>
            </span>
        </div>
    </div>
</nav>

<?php /**PATH C:\Users\Maruf Nishan\Desktop\quizapp\resources\views/navigation-menu.blade.php ENDPATH**/ ?>