<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Exam Invitation</title>
    <style>
        .button {
  background-color: aqua;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
}
    </style>
</head>
<body style="text-align:center">
    <p>Hi we are from biddahpith.com Your Friend <?php if($invitation->user_id ): ?> <?php echo e($invitation->user->name); ?> <?php endif; ?> have invited you to participate this exam hope you will enjoy it !!</p>
    <table style="width: 600px;">
        <thead>
            <tr>
                
                <th>Exam Name</th>
                <th>Exam Thumbnail</th>
            </tr>
        </thead>

        <tbody>
                <tr>
                    <td><?php echo e($invitation->exam->exam_title); ?></td>
                    <td><img src="<?php echo e(asset('assets/img/examthumbnail')); ?>/<?php echo e($invitation->exam->exam_thumbnail); ?>" width="100" /></td>
                </tr>
        </tbody>
    </table>
    <a href="<?php echo e($invitation->invitation_link); ?>"><button class="button">Participate Now</button></a>
</body>
</html><?php /**PATH C:\Users\Maruf Nishan\Desktop\quizapp\resources\views/mails/invitation-mail.blade.php ENDPATH**/ ?>