<div>
     <?php $__env->slot('header', null, []); ?> 
        <div class="md:flex justify-between">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('চ্যাম্পিয়নশিপ প্রস্তুতি চ্যালেঞ্জ')); ?>

            </h2>
        </div>
     <?php $__env->endSlot(); ?>
    
    <div class="container my-3" style="background-color: #FFFFFF;">
        <div class="row">
            <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 my-3 d-flex justify-content-around">
                <div class="card" style="width: 18rem;">
                    <?php if(!empty($exam->exam_thumbnail)): ?>
                    <img src="<?php echo e(asset('assets/img/examthumbnail')); ?>/<?php echo e($exam->exam_thumbnail); ?>" class="card-img-top" alt="championship_thumbnail">
                    <?php else: ?>
                    <img src="<?php echo e(asset('assets/img/std.jpg')); ?>" class="card-img-top" alt="championship_thumbnail">
                    <?php endif; ?>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($exam->exam_title); ?></h5>
                        <p class="text-sm"><b>Total Question :</b>
                            <?php echo e($exam->lavel->where('exam_id',$exam->id)->sum('question_size')); ?></p>
                            <?php if(Auth::user()): ?>
                            <?php if(!empty($enrolls)): ?>
                            <?php $__currentLoopData = $enrolls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enroll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if( $exam->id == $enroll->exam_id && $enroll->user_id == auth()->id() && $enroll->exam_state == 'Created'): ?>
                                    <a href="<?php echo e(route('quizLavel',$exam->id)); ?>" class="btn btn-primary">Participate Now</a>
                                <?php endif; ?>
                                <?php if($enroll->exam_id == $exam->id && $enroll->user_id == auth()->id() && $enroll->exam_state == 'Participate'): ?>
                                    <a href="<?php echo e(route('userShowreasult',[$exam->id,auth()->id()])); ?>" type="button" class="btn btn-warning">Show Reasult</a>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('champEnroll',$exam->id)); ?>" class="btn btn-success">Enroll Now</a>
                        <?php else: ?>
                        <a href="<?php echo e(route('champEnroll',$exam->id)); ?>" class="btn btn-danger">Enroll Now</a>
                        <a href="<?php echo e(route('Invitation',$exam->id)); ?>" class="btn btn-primary">Invite</a>
                        <?php endif; ?>
                            <?php else: ?>
                        <a href="<?php echo e(route('quizLavel',$exam->id)); ?>" class="btn btn-success me-3">Practice</a>
                        <a href="<?php echo e(route('Invitation',$exam->id)); ?>" class="btn btn-primary">Invite</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    
</div>
<?php /**PATH C:\Users\Maruf Nishan\Desktop\quizapp\resources\views/livewire/championship-practice.blade.php ENDPATH**/ ?>