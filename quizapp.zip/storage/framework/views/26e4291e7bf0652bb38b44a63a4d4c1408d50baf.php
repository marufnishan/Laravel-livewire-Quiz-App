<div>
    <div class="dropdown-content">
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('catJobPeparation',$categorie->id)); ?>"><?php echo e($categorie->cat_name); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('allTeacher')); ?>">সমন্বিত</a>
    </div>
</div>
<?php /**PATH C:\Users\Maruf Nishan\Desktop\quizapp\resources\views/livewire/catecogy-component.blade.php ENDPATH**/ ?>