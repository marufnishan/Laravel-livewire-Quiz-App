<x-app-layout>
    <livewire:user-datatable />
</x-app-layout>